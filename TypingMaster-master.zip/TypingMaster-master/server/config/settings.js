module.exports = {
  'secret':'cis422group2'
};